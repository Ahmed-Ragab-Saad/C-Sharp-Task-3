﻿using System.Text;

namespace Day3
{
    class Day3
    {
        public static void Main(string[] args)
        {
            #region Problem 1
            ////--1
            //string s = Console.ReadLine();
            //try
            //{
            //    int number1 = int.Parse(s);
            //    int number2 = Convert.ToInt32(s);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //}
            ////int.Parse() => Cannot handle null inputs
            ////Convert.ToInt32() => Can handle null inputs 
            #endregion

            #region Problem 2
            ////--2
            //int number;
            //if (int.TryParse(Console.ReadLine(), out number))
            //{
            //    Console.WriteLine(number);
            //}
            //else
            //{
            //    Console.WriteLine("Cannot convert from string to int");
            //} 
            #endregion

            #region Problem 3
            ////--3
            //Object o = 5;
            //Console.WriteLine(o.GetHashCode());
            //o = "Hello";
            //Console.WriteLine(o.GetHashCode());
            //o = 77.7d;
            //Console.WriteLine(o.GetHashCode());
            ////The GetHashCode() method in .NET serves a critical role in generating a hash code, which is a numeric value
            ////used for efficient lookups in data structures like hash tables, dictionaries, and sets. 
            #endregion

            #region Problem 4
            ////--4
            //Employee e1 = new Employee() { Name = "Ahmed" };
            //Employee e2 = e1;
            //Console.WriteLine($"Before: e1: {e1.Name}, e2: {e2.Name}");
            //e2.Name = "Mohamed";
            //Console.WriteLine($"After: e1: {e1.Name}, e2: {e2.Name}"); 
            ////Reference equality: determines whether two object references point to the same memory location
            #endregion

            #region Problem 5
            ////--5
            //string s = "Welcome ";
            //Console.WriteLine(s.GetHashCode());
            //s += "Hi Willy";
            //Console.WriteLine(s.GetHashCode());
            ////Reasons for String Immutability:
            ////1. Memory Efficiency with String Interning
            ////2. Thread-Safety
            ////3. Security
            ////4. Predictable Behavior
            ////5. Caching and Performance Optimizations
            ////6. Functional Programming Paradigm 
            #endregion

            #region Problem 6
            ////--6
            //StringBuilder sb = new StringBuilder("Hi Willy");
            //Console.WriteLine(sb.GetHashCode());
            //sb.Append(", Welcome");
            //Console.WriteLine(sb.GetHashCode());
            ////Strings in C# are immutable. Every time you modify a string (e.g., concatenation),
            ////a new string object is created, and the old one is discarded.
            ////StringBuilder class is designed to handle scenarios where frequent modifications to strings (concatenation, insertion, deletion) are required.
            ////StringBuilder:
            ////Is mutable 
            ////Don't create a new object when change it 
            #endregion

            #region Problem 7
            //--7
            //because it avoids the repeated memory allocation and data copying associated with immutable strings.
            //By maintaining a mutable buffer and resizing it only when necessary 
            #endregion

            #region Problem 8
            ////--8
            //int num1 = int.Parse(Console.ReadLine());
            //int num2 = int.Parse(Console.ReadLine());
            //Console.WriteLine("Sum is: " + (num1 + num2));
            //Console.WriteLine(String.Format("Sum is: {0}", num1 + num2));
            //Console.WriteLine($"Sum is: {num1 + num2}");
            ////String Interpolation is the most used in C#, because of its clean syntax, readability, and performance. 
            #endregion

            #region Problem 9
            ////--9
            //StringBuilder sb = new StringBuilder("Hello my name is");
            //sb.Append(" Ahmed");
            //sb.Replace("Hello", "Welcome");
            //sb.Insert(7, " all");
            //sb.Remove(7, 4);
            //Console.WriteLine(sb);
            ///*
            // * Strings are immutable:
            // * Once a string object is created, it cannot be changed. 
            // * Any modification (appending, inserting, replacing characters) creates a new string object.
            // */
            ///*
            // * StringBuilder is mutable:
            // * StringBuilder uses a dynamic character buffer that can be modified directly, without creating new objects each time.
            // * It allows you to append, insert, or remove characters in place, modifying the buffer rather than creating new strings.
            // */ 
            #endregion


        }
    }
    //Problem 4
    class Employee
    {
        public string Name { get; set; }
    }
}